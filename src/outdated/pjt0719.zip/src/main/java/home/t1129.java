package home;

import javax.servlet.http.HttpServletRequest;

public class t1129 {
	public String getClientIP(HttpServletRequest request) {

		String ip = request.getHeader("X-FORWARDED-FOR");

		if (ip == null || ip.length() == 0) {
		ip = request.getHeader("Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0) {
		ip = request.getHeader("WL-Proxy-Client-IP"); // ������
		}

		if (ip == null || ip.length() == 0) {
		ip = request.getRemoteAddr() ;
		}
		System.out.print(ip);
		return ip;
	}
}
