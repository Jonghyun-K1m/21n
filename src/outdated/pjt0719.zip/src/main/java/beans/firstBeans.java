package beans;

public class firstBeans {

    private String beans_id;
    private String beans_pwd;
    private String beans_name;
     
    public firstBeans() {
        // TODO Auto-generated constructor stub
        this.setBeans_id("null");
        this.setBeans_pwd("null");
        this.setBeans_name("null");
    }

	public String getBeans_id() {
		return beans_id;
	}

	public void setBeans_id(String beans_id) {
		this.beans_id = beans_id;
	}

	public String getBeans_pwd() {
		return beans_pwd;
	}

	public void setBeans_pwd(String beans_pwd) {
		this.beans_pwd = beans_pwd;
	}

	public String getBeans_name() {
		return beans_name;
	}

	public void setBeans_name(String beans_name) {
		this.beans_name = beans_name;
	}
}
