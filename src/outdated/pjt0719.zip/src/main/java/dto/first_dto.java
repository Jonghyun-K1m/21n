package dto;

public class first_dto {
	
	private String user_id;
	private String user_pwd;
	
	public String getuser_id() {
		return user_id;
	}
	public void setuser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getuser_pwd() {
		return user_pwd;
	}
	public void setuser_pwd(String user_pwd) {
		this.user_pwd = user_pwd;
	}

	

	

	
}
