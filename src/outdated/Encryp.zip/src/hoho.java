import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Formatter;
import javax.crypto.Cipher; 

public class hoho { 
	public static void main(String[] args) throws Exception {
		String prigo="C:\\Users\\user\\eclipse-workspace\\Encryp\\keyhome\\local.pem";
		String pubgo="C:\\Users\\user\\eclipse-workspace\\Encryp\\keyhome\\local_pub.der";
		File publicKeyFile = new File(pubgo);
		File privateKeyFile = new File(prigo);
		System.out.println(publicKeyFile);
		PublicKey publicKey = null;
		PrivateKey privateKey = null;
		if (publicKeyFile.exists() && privateKeyFile.exists()) {
			// ���Ͽ��� Ű �о����
			Path publicFile = Paths.get(prigo);
			byte[] publicKeyBytes = Files.readAllBytes(publicFile);
			Path privateFile = Paths.get(pubgo);
			byte[] privateKeyBytes = Files.readAllBytes(privateFile);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			privateKey = keyFactory.generatePrivate(new PKCS8EncodedKeySpec(privateKeyBytes));
			publicKey = keyFactory.generatePublic(new X509EncodedKeySpec(publicKeyBytes));

		} else {
			System.out.println("�����");
/*			// ����Ű�� ����
			KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
			generator.initialize(1024);
			KeyPair pair = generator.generateKeyPair();
			publicKey = pair.getPublic();
			privateKey = pair.getPrivate();
			FileOutputStream outputPublic = new FileOutputStream(new File("public.key"));
			outputPublic.write(publicKey.getEncoded());
			FileOutputStream outputPrivate = new FileOutputStream(new File("private.key"));
			outputPrivate.write(privateKey.getEncoded());
			*/
		}
		System.out.println("����Ű: "+bytesToHex(publicKey.getEncoded()));
		System.out.println("����Ű: "+bytesToHex(privateKey.getEncoded()));
		
		// ��ȣȭ
		String plainText = "���õ� ���� �ٶ��� ��ġ���.";
		System.out.println("��: "+plainText);
		Charset charset = Charset.forName("UTF-8");
		byte[] encryptData = encrypt(publicKey, plainText.getBytes(charset));
		System.out.println("��ȣ��: "+bytesToHex(encryptData));
		
		// ��ȣȭ
		byte[] plainData = decrypt(privateKey, encryptData);
		String decryptedText = new String(plainData, charset);
		System.out.println("��ȣȭ: "+decryptedText);
	}

	public static byte[] encrypt(PublicKey publicKey, byte[] plainData)
	throws GeneralSecurityException {
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptData = cipher.doFinal(plainData);
		return encryptData;
	}
	
	public static byte[] decrypt(PrivateKey privateKey, byte[] encryptData)
	throws GeneralSecurityException {
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] plainData = cipher.doFinal(encryptData);
		return plainData;
	}
		
	public static String bytesToHex(byte[] bytes) {
	    StringBuilder sb = new StringBuilder(bytes.length * 2);
	    @SuppressWarnings("resource")
		Formatter formatter = new Formatter(sb);
	    for (byte b : bytes) {
	        formatter.format("%02x", b);
	    }
	    return sb.toString();
	}
}