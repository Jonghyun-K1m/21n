import java.text.SimpleDateFormat;
import java.util.Calendar;

public class time {

	public time()
	{
		
	}
	
	public String time_get()
	{
		SimpleDateFormat format1 = new SimpleDateFormat ("yyMMdd");
		SimpleDateFormat format2 = new SimpleDateFormat ( "HHmmss");
				
		Calendar time = Calendar.getInstance();
		       
		String format_time1 = format1.format(time.getTime());
		String format_time2 = format2.format(time.getTime());

	//	System.out.println(format_time1);
	//	System.out.println(format_time2);
		
		format_time1=format_time1+format_time2;
	//	System.out.println(format_time1);
		return format_time1;
	}
	public String time_get(String padd_to_begin)
	{
		SimpleDateFormat format1 = new SimpleDateFormat ("yyMMdd");
		SimpleDateFormat format2 = new SimpleDateFormat ( "HHmmss");
				
		Calendar time = Calendar.getInstance();
		       
		String format_time1 = format1.format(time.getTime());
		String format_time2 = format2.format(time.getTime());

	//	System.out.println(format_time1);
	//	System.out.println(format_time2);
		
		format_time1=padd_to_begin+format_time1+format_time2;
	//	System.out.println(format_time1);
		return format_time1;
	}
	public static void main(String[] args)
	{
	
		
	}
}
