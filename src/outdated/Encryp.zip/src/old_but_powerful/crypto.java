package old_but_powerful;

import javax.crypto.Cipher;
import java.io.UnsupportedEncodingException;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.HashMap;

public class crypto {
    static final int KEY_SIZE = 2048;
   // static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjNw0K5CD6vrhJfZouF8e+vBE6/oYLa43ntnl1Sz/jI2DaaggWem2KNnHoyu2Y+qn2ncBdWvp3eX2cTVRreZo9kJPtNQLQWDTrM6eum61fsBv9O5aKMarpaBisqk+zazeSZojJFkgpF20382ZQN4NkXlxopt04f8M7XnSMzHEUhlc6MBffYsoJALxv34E71/L3mJbcDGbHr3QdW/pzrOr8DEQ9z+UmBAPxCH1wKkKfSal5lcJAM8vtBLgXjReEQH8Tp6nwDWEZYgKoyQK0hD+bclE8UUeE0IeNITNaL3774mMruHF7f+7nIH0iaMBvLwR4CPo7YHG9FLPQV9ehyb7hQIDAQAB";
   // static String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCM3DQrkIPq+uEl9mi4Xx768ETr+hgtrjee2eXVLP+MjYNpqCBZ6bYo2cejK7Zj6qfadwF1a+nd5fZxNVGt5mj2Qk+01AtBYNOszp66brV+wG/07looxquloGKyqT7NrN5JmiMkWSCkXbTfzZlA3g2ReXGim3Th/wztedIzMcRSGVzowF99iygkAvG/fgTvX8veYltwMZsevdB1b+nOs6vwMRD3P5SYEA/EIfXAqQp9JqXmVwkAzy+0EuBeNF4RAfxOnqfANYRliAqjJArSEP5tyUTxRR4TQh40hM1ovfvviYyu4cXt/7ucgfSJowG8vBHgI+jtgcb0Us9BX16HJvuFAgMBAAECggEAcZBTS1Au2vK7NKUN1p9x1bSCjJHMjn+n/h0EzDKEMWgiK7vNoU/oedTivC3Q1YtpGpvZhDaljS4K20i2enKJ6wiZRFu0W1haMDdBB2OcVf2GBb1o2Pkbh+PfztTeemnFqSdo77QfugSGf+09gmvEGqYDtKqKuG2tmYQesQGNmvX/V/xJHPmiZPupKnQyiFAZ9A4eTQrCdTZZoOX9DTrtHaDuUsxaMxzFVV8VYDMlDIYZisHvqRhh5AHGtyxPdaG+VkiMUsP73aeFElHZ7RvMpoOGx7pHP3+cUkAY+DGU8WHjkVcB2OoAO0CiSGJvmcIiS/5aUcyAaCZnMOsRXQAXYQKBgQDF/Rsdwif/PqF2JT2r1ecJExhvEBf4pwyfyq5XgVWpNF76oqsEtcznxwNlkP6z8nN4lHg6wNJhWhGlAkbETjnRDGD96MVmIFeyv40NrGOP1xpl+lvXxXQglOuJJyHxdbSaUOMAUPRQmEaAVbIejyMvo3F6rb//nIqqmpUNQ09WyQKBgQC2IfS4eWOFdpt0HwUD4HJg7qXbcOcRoOpEGrQrk1hPqUwywMSU7OIGR+CJoSFIpww9ONpSagX324o2rdHYSrg4FqK4KYCqf6SaQgGlwGvYXXYzjIDKVqrA1TAuL3x5eOSHXzfdlR5nvXI15Rudx+ydxn437NgDBYSYm4T1aBiQ3QKBgFuA9BRX1IZ6GsNwyMTvMj0Wbzd9V6bbBdGgKd1VcBKomrD5l1Kw90ezydUaIy1lg4qaC8sTrOfDad46ZBx8DuqX7wfKmdjuX7nEH9vO7aDgCFpTUDk0D8yzJvyXcm+XN+YONivCPng1OHg9ovnOq7NrtZm+TbtETS42DWc40aVJAoGAJJpwZz6mHKV4mn69cEkEU6zCknZ/SdCwJB3Fxdgn8GKS2MRa/Z8Z0a9SVfaXDNXdpNQvNE7wgh6SCWknejOSEFukOiTFIf7jIslPMXOZePNXlQaQv5lpWbW+qBmNB5CfRQGC5bpZUPoG4QP5Z91NFWxV44Fq7DiIrG7c6sEP5tUCgYEApjG+ROoTq/jCqC1o6rTX5Izr2U9gqTNpBXI6GTLIneM09/sZEgWotVhbnH4YKXnIapSWQu7zM/Kt9IXRlK9vK1T6qDV2iZp2PvoLgnov0tbE3dOVRfRBLrX9pg7luwjWfi5xsQle0yts05NX+FWYjKiTKYJRQcTKaFcE62DjC6k=";
  static String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2CyUeL3Jt/XQg7mcnpgb946t4GlZ9ka6t51g/TTR5gKxH7dOthNch5pcElcmR3gdL6WagbeZ9rMYQshsP76VI4NGRydyjXJGPPdKBnoogqiHGXRyfNDSEai0VaK5gp4JGManSrC2BAeEeAkh0N9iptAPw32QJnfaDfILBBwwy2FsS6cEsPfVSd/4fJlvQ6TDmEfodaC8a1KLoNMOimy33kxircVuzjB3Uup2xrGr0F2GMyYoywy0fnOeLbklA9TfuZcqaCWL2dJryJSnL9FkJtA8a68t1zYYuPrLDgyfhqj1Blr1O/eBDlLliZ8aq49NwgCtS3M/wwND71x7B3BnBQIDAQAB";
	static String privateKey = "MIIE8DAaBggqgxqMmkQBDzAOBAiKKfSEkG742QICCAAEggTQwtmvMNy/n7bfHr7ctiTOnrrL47+dulExexfFJEDu1sGrgRYIjgOEHR0U9Ipd63xoYVEYdzmi89b1pq84S9n3QRf4izA4TejD+quljtzBVbl20YS31fS9vzz2LPYaWSMNJsoody31+tiOCNi5tLmMDUQFlJmZjnZ6yky3iA4C5tR0xplYePqMG6cdNJ7s46hsgFMxAnSJ3TlVSKCoNBM67hY7hRzRab79FIaritNRuy3pK/r4XNxbeLKtQWVxN/lkiPW6gw2vks1d5hLaVoLzD7ta2HES5UtV9qgqEHi+33jEf05WtGfMuIHnh9pDqHaCmo55ReS/tLiXd1rAJgkmyXQr9JQ2yyXTEs9yRoACKNRGW9UYcRxcNGFeX6njbpyrYXC1+UBuFD4EgCsfj2FqSRpwYH73S9yQx2OiT9tLH416OzIufSFXrLwJuz/IKpfyBRaCuj5IcjqU803J6WZfoTsuwf1h7XeWxL8BHcsWF1BCvNSd/nPfdmHTWLPJjqREAhxfmD/fA1BBFsSeRdDZ+WY66jc4QFvzc9Y47kRs5unzMX+scq9/2cUUmg5ookhdVqANl9hnZmLAJ0XE2Xc6FXspZ1ImO9QTCxteKxWrfiJTuRITJT5r3cs8+IpgnIdj5WmZe1Sit/SqJs7mI6DxAmjb0BLNUXr3fZRsLPHu2hFwS1DMkV6QVJmO9SnYBF8T0CSMl8Od1gMsvNbm7l6DdC/fusq8BLd84GjLWsC60je4LJrVj4u9SbpCA1pynmq5Bx003Zg16OeGS7xtWrAg8SB6i915Ldet1mUdSMW4TXeDYF8bLJmmjS2/2YDMkfQPbNaeZByXCXOYwH7cFMtiPSZDbALJWLsqld6anRCwJKpAV+jJ89jpXYqIujh1fSCTdO6fllTIK4KXYNz/k8PZqCa5ISyZW6h4zTc0tL3xYwJAFOooemM18M/RpjE6EdW/z9V1eyEVyRC4h8Wy5gEABJ3Y74Ssuh6VQPfqov1IlBTra58mfqFcLLqmKwm3BMu7e0k0D9PDNJ6kxRt8v8EQN2f3KUXIDiJj2vHi+pRGln2GSNPj1gAjBzUpTKmCrS/BgMAU+Ay1mY1YqQPzj9h8uJII7cNRouesDwudUAfDOdBP5CQrUxcBZiw852LvHc+b966FVPIzL7/DDYsrPZhZ2cHu5VtT3QXJS0ekSPYgeaUbLT+1uuWuZlkZd+OqfKjrvOHykrSMLWPUAqwfV15kFFklyMtVyF1nLzX/H8lQwp80jtoz6iUT17PfGuJ280XA4l/2MmiH/6lZWGcMS+Obh+5191OfVA1I9Ycs9ejhoA6QlUIWWRx0gsDvaSn+k/hH6p+Dgb8BkIave8JudWSmnw46TfqJ80b8A0+mXI3+enO3MO1okzV0sM92fLCTy5XLAfWUrvoYpHUyU8U/N5kq7mlTH1iXkrE+zRwZqI0vtlKFMD/yLkPK5NauBA5+YY2llqeed/Ck619ZS/NbLXyjc68j0lylHe+mgCDTQDFvYsjYx6v13VgfNXqBkr4bOWjzksP2bkDvadhTukmfeR53+ccGH4bNKIq78DB+JtHccy5X8jWXzdt1ou26f3uj5VKmO8jNIV0A3Yb6+Br8NPtBtiWLmzEVyPL25lIQxi41BuU=";
    public static void main(String[] args) {

        System.out.println("������� ����Ű:" + publicKey);
        System.out.println("������� ����Ű:" + privateKey);

        String plainText = "a";
        System.out.println("��: " + plainText);
        String encryptedText = encode(plainText, publicKey);
        System.out.println("��ȣȭ: " + encryptedText);
        String decryptedText = decode(encryptedText, privateKey);
        System.out.println("��ȣȭ: " + decryptedText);
        String signText = sign(plainText,privateKey);
        System.out.println("����: "+signText);
        boolean result = verifySignarue(plainText, signText, publicKey);
        System.out.println("����: " + result);
    }

    /**
     * ��ȣȭ
     */
    static String encode(String plainData, String stringPublicKey) {
        String encryptedData = null;
        try {
            //������ ���޹��� ����Ű�� ����Ű��ü�� ����� ����
            PublicKey publicKey =  getPublicKey(stringPublicKey);
            //������� ����Ű��ü�� ������� ��ȣȭ���� �����ϴ� ����
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            //���� ��ȣȭ�ϴ� ����
            byte[] byteEncryptedData = cipher.doFinal(plainData.getBytes());
            encryptedData = Base64.getEncoder().encodeToString(byteEncryptedData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return encryptedData;
    }
    /**
     * ��ȣȭ
     */
    static String decode(String encryptedData, String stringPrivateKey) {
        String decryptedData = null;
        try {
            //������ ���޹��� ����Ű�� ����Ű��ü�� ����� ����
            PrivateKey privateKey = getPrivateKey(stringPrivateKey);
            //������� ����Ű��ü�� ������� ��ȣȭ���� �����ϴ� ����
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            //��ȣ���� ��ȭ�ϴ� ����
            byte[] byteEncryptedData = Base64.getDecoder().decode(encryptedData.getBytes());
            byte[] byteDecryptedData = cipher.doFinal(byteEncryptedData);
            decryptedData = new String(byteDecryptedData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return decryptedData;
    }

    static PublicKey getPublicKey (String stringPublicKey) {
        PublicKey publicKey = null;
        try {
            //������ ���޹��� ����Ű�� ����Ű��ü�� ����� ����
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] bytePublicKey = Base64.getDecoder().decode(stringPublicKey.getBytes());
            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(bytePublicKey);
            publicKey = keyFactory.generatePublic(publicKeySpec);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return publicKey;
    }
    static PrivateKey getPrivateKey (String stringPrivateKey) {
        PrivateKey privateKey = null;
        try {
            //������ ���޹��� ����Ű�� ����Ű��ü�� ����� ����
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] bytePrivateKey = Base64.getDecoder().decode(stringPrivateKey.getBytes());
            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(bytePrivateKey);
            privateKey = keyFactory.generatePrivate(privateKeySpec);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return privateKey;
    }
    public static String sign(String plainText,String strPrivateKey) {
        try {
            PrivateKey privateKey = getPrivateKey(strPrivateKey);
            Signature privateSignature = Signature.getInstance("SHA256withRSA");
            privateSignature.initSign(privateKey);
            privateSignature.update(plainText.getBytes("UTF-8"));
            byte[] signature = privateSignature.sign();
            return Base64.getEncoder().encodeToString(signature);
        } catch (NoSuchAlgorithmException | InvalidKeyException | UnsupportedEncodingException | SignatureException e) {
            throw new RuntimeException(e);
        }
    }
    public static boolean verifySignarue(String plainText, String signature, String strPublicKey) {
        Signature sig;
        try {
            PublicKey publicKey = getPublicKey(strPublicKey);
            sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(publicKey);
            sig.update(plainText.getBytes());
            if (!sig.verify(Base64.getDecoder().decode(signature)));
        } catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException e) {
            throw new RuntimeException(e);
        }
        return true;
    }
}