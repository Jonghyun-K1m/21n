package old_but_powerful;

public class yell {

	public static void main(String[] args)
	{
		while(true)
		{
			System.out.println("1");
			try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
