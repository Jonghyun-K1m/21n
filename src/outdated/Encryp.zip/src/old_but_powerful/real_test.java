
package old_but_powerful;

import com.jh.Crpto.*;

public class real_test {

	
	
	public static void main(String[] args)
	{
		classic a =new classic();

	}
}
