package com.jh.Crpto;

public class key_iv_call {

	public key_iv_call()
	{
		pvkey="kakaka";
		iv="ooooo";
	}
	private String pvkey;
	private String iv;
	
	public String getPvkey() {
		return pvkey;
	}
	public void setPvkey(String pvkey) {
		this.pvkey = pvkey;
	}
	public String getIv() {
		return iv;
	}
	public void setIv(String iv) {
		this.iv = iv;
	}
	
}
