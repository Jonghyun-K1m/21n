package com.jh.Crpto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;


public class ad {


    public byte[] encrypt(String str) {
    	
    	key_iv_call ca=new key_iv_call();
    	
    	  //byte[] bytes = string.getBytes(StandardCharsets.UTF_8);
        byte[] enc = null;
        byte[] bytes1 = ca.getPvkey().getBytes(StandardCharsets.UTF_8);
		byte[] bytes2 = ca.getIv().getBytes(StandardCharsets.UTF_8);
		//��ȣȭ �Լ� ȣ��
		//( byte[] pbszUserKey, byte[] pbszIV, byte[] message, int message_offset, int message_length )
     
		enc = KISA_SEED_CBC.SEED_CBC_Encrypt(bytes1, bytes2, str.getBytes(StandardCharsets.UTF_8), 0, str.length());
		//enc = KISA_SEED_ECB.SEED_ECB_Encrypt(pbUserKey, str.getBytes(CHARSET),  0, str.getBytes(CHARSET).length);

        /**JDK1.8 �� �� ���
        Encoder encoder = Base64.getEncoder();
        byte[] encArray = encoder.encode(enc);
        */
      //  byte[] encArray  = Base64.encode(enc);
        byte[] encArray  = Base64.getEncoder().encode(enc);
        
        //Base64.getEncoder().encodeToString(byteEncryptedData);       
        return encArray;
    }	
    public static String decrypt(byte[] str) {
        
    	/**JDK1.8 �� �� ���
    	Decoder decoder = Base64.getDecoder();
        byte[] enc = decoder.decode(str);
        */
    	key_iv_call ca=new key_iv_call();
    	
  	  //byte[] bytes = string.getBytes(StandardCharsets.UTF_8);
      byte[] bytes1 = ca.getPvkey().getBytes(StandardCharsets.UTF_8);
		byte[] bytes2 = ca.getIv().getBytes(StandardCharsets.UTF_8);
	    	
  //  	byte[] enc  = Base64.decode(str);
    	byte[] enc  = Base64.getDecoder().decode(str);
    //    byte[] byteEncryptedData = Base64.getDecoder().decode(encryptedData.getBytes());
            
        String result = "";
        byte[] dec = null;


        try {
            //��ȣȭ �Լ� ȣ��
            dec = KISA_SEED_CBC.SEED_CBC_Decrypt(bytes1, bytes2, enc, 0, enc.length);
        	//dec = KISA_SEED_ECB.SEED_ECB_Decrypt(pbUserKey, enc, 0, enc.length);
            result = new String(dec, "UTF_8");

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

       return result;
    }
    /***************************************
     * Main �Լ�
     * @param args
     **************************************/
  /*
    public static void main(String[] args) {

    	
    	//String filePath = "C:/egov_dev/workspace/JavaSample/testdata/case0.txt";
    	
        try {
        	
        	//String plainText = fileRead(filePath);
        	String plainText ="s1234123123123123123123123123123123123123123123123123123123123123121275";
		
		
        	
        	/*************************************
        	 * ��ȣȭ
        	 *************************************/
        	byte[] encryptData = encrypt(plainText);
            //System.out.println("encrypt:" + new String(encryptData, "utf-8"));
            
            /*************************************
             * ��ȣȭ
             *************************************/
            plainText = decrypt(encryptData);
            String decryptedData = new String(encryptData);
            System.out.println(decryptedData);
            //System.out.println("decrypt:" + plainText);
            
			/* (2)���� �ð�  ����   */
			long endTimeLong = getCurrentTimeLong();
			/*test*/System.out.println( "endTimeLong : " + endTimeLong );

			/* (3)�ý��� ���Ⱓ ���
			 *  - �ð� ���̴� ��(sec)������ ���Ǹ� long Ÿ�� ������ ����ȴ�.
			 */
			//long useTime = Math.abs( endTimeLong - startTimeLong )/1000; //���밪�� ��ȯ - sec
			//*test*/System.out.println( "  useTime : " + useTime + "(Sec)");
			long useTime = Math.abs( endTimeLong - startTimeLong ); //���밪�� ��ȯ - �и�����
			/*test*/System.out.println( "  useTime : " + useTime + "(MM)");
            
        } catch (Exception e) {
			e.printStackTrace();
		}
        
    }*/


    
	//��ü ���� ���� �о����

	/**
	 * - �뵵 : ���� �ð��� long Ÿ������ ��ȯ�ϸ� �ð� ���� ���ϴ� �Լ��� ���
	 * - Return Type: long
	 * - Argument Type : none
	 */

}
