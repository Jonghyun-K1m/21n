package com.jh.Crpto;

import com.jh.config.getProperties;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidAlgorithmParameterException;

import org.apache.commons.codec.binary.Base64;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64.Encoder;
import java.util.Formatter;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;


/*
 * call 1 = encode
 * call 2 = decode
 * 
 */
public class trim {
	
	public trim()
	{
	}
	public String trim_request(int call) throws IOException
	{
	
		getProperties getP= new getProperties();

		String file_call=null;
		switch(call)
		{
			case 1:
				file_call=getP.get_svPubkey();
				break;
			
			case 2:
				file_call=getP.get_myPrikey();				
				break;

			default:
				break;
		}

		File f = new File(file_call);
		FileInputStream fis = new FileInputStream(f);
		DataInputStream dis = new DataInputStream(fis);
		byte[] keyBytes = new byte[(int) f.length()];
		dis.readFully(keyBytes);
		dis.close();

		String temp = new String(keyBytes);
		String returnstr=null;
		switch(call)
		{
			case 1:
				file_call=getP.get_svPubkey();
		      	returnstr = temp.replace("-----BEGIN PUBLIC KEY-----\n", "")
		      			.replace("-----END PUBLIC KEY-----", "")
		      	//		.replace("-----BEGIN RSA PUBLIC KEY-----\n", "")
		      	//		.replace("-----END RSA PUBLIC KEY-----", "")
		      			.replaceAll("\\n", "");  
		      	
				break;
			
			case 2:
				file_call=getP.get_myPrikey();	
		      	returnstr = temp.replace("-----BEGIN PRIVATE KEY-----\n", "")
		      			.replace("-----END PRIVATE KEY-----", "")
		      	//		.replace("-----BEGIN RSA PRIVATE KEY-----\n", "")
		      	//		.replace("-----END RSA PRIVATE KEY-----", "")
		      			.replaceAll("\\n", "");  	      	
				break;

			default:
				break;
		}

		return returnstr;
      	
	}

}