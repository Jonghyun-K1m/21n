package com.jh.Crpto;

import java.io.UnsupportedEncodingException;
import java.util.Base64;





public class classic {
	public static String CHARSET = "utf-8";
	private static String PBUserKey = ""; //16Byte�� ����
	public static byte pbUserKey[] = PBUserKey.getBytes();
	private static String DEFAULT_IV = "1234567890123456"; //16Byte�� ����
	private static byte bszIV[] = DEFAULT_IV.getBytes();
	
	public void setuser_id(String PBUserKey) {
		this.PBUserKey = PBUserKey;
	}	
	
    public static byte[] encrypt(String str) {

        byte[] enc = null;
        try {

        	//��ȣȭ �Լ� ȣ��
        	//( byte[] pbszUserKey, byte[] pbszIV, byte[] message, int message_offset, int message_length )
            enc = KISA_SEED_CBC.SEED_CBC_Encrypt(pbUserKey, bszIV, str.getBytes(CHARSET), 0, str.length());
            //enc = KISA_SEED_ECB.SEED_ECB_Encrypt(pbUserKey, str.getBytes(CHARSET),  0, str.getBytes(CHARSET).length);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        /**JDK1.8 �� �� ���
        Encoder encoder = Base64.getEncoder();
        byte[] encArray = encoder.encode(enc);
        */
      //  byte[] encArray  = Base64.encode(enc);
        byte[] encArray  = Base64.getEncoder().encode(enc);
        
        //Base64.getEncoder().encodeToString(byteEncryptedData);       
        return encArray;
    }
    public static String decrypt(byte[] str) {
        
    	/**JDK1.8 �� �� ���
    	Decoder decoder = Base64.getDecoder();
        byte[] enc = decoder.decode(str);
        */
    	
  //  	byte[] enc  = Base64.decode(str);
    	byte[] enc  = Base64.getDecoder().decode(str);
    //    byte[] byteEncryptedData = Base64.getDecoder().decode(encryptedData.getBytes());
            
        String result = "";
        byte[] dec = null;

        try {
            //��ȣȭ �Լ� ȣ��
            dec = KISA_SEED_CBC.SEED_CBC_Decrypt(pbUserKey, bszIV, enc, 0, enc.length);
        	//dec = KISA_SEED_ECB.SEED_ECB_Decrypt(pbUserKey, enc, 0, enc.length);
            result = new String(dec, CHARSET);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

       return result;
    }
}
