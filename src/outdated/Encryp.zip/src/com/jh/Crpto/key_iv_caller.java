package com.jh.Crpto;

public class key_iv_caller {

	
	

	
	public static void main()
	{
	  	String plainText ="s1234123123123123123123123123123123121275";
		
    	byte[] encryptData = encrypt(plainText);
        
	}
}
