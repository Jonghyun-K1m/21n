import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidAlgorithmParameterException;

import org.apache.commons.codec.binary.Base64;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64.Encoder;
import java.util.Formatter;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;


public class PemFile{
	   static String encode(String plainData, String stringPublicKey) {
	        byte[] encryptedData = null;
	        String str = null;
	        try {
	            //������ ���޹��� ����Ű�� ����Ű��ü�� ����� ����
	            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	            byte[] bytePublicKey = Base64.decodeBase64(stringPublicKey.getBytes());
	            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(bytePublicKey);
	            PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);

	            //������� ����Ű��ü�� ������� ��ȣȭ���� �����ϴ� ����
	            Cipher cipher = Cipher.getInstance("RSA");
	            cipher.init(Cipher.ENCRYPT_MODE, publicKey);

	            //���� ��ȣȭ�ϴ� ����
	            byte[] byteEncryptedData = cipher.doFinal(plainData.getBytes());
	            encryptedData = Base64.encodeBase64(byteEncryptedData);
	            str = new String(encryptedData);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return str;
	    }

	    /**
	     * ��ȣȭ
	     */
	    static String decode(String encryptedData, String stringPrivateKey) {
	        String decryptedData = null;
	        try {
	            //������ ���޹��� ����Ű�� ����Ű��ü�� ����� ����
	            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	            byte[] bytePrivateKey = Base64.decodeBase64(stringPrivateKey.getBytes());
	            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(bytePrivateKey);
	            PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);

	            //������� ����Ű��ü�� ������� ��ȣȭ���� �����ϴ� ����
	            Cipher cipher = Cipher.getInstance("RSA");
	            cipher.init(Cipher.DECRYPT_MODE, privateKey);

	            //��ȣ���� ��ȭ�ϴ� ����
	            byte[] byteEncryptedData = Base64.decodeBase64(encryptedData.getBytes());
	            byte[] byteDecryptedData = cipher.doFinal(byteEncryptedData);
	            decryptedData = new String(byteDecryptedData);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return decryptedData;
	    }

//����Ű�� ��ȣȭ(Ű������ ������������ �����ID, ��ȣȭ ��� ��)
public static void main (String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
    final String PRIVATE_KEY="keyhome/local_pri.der";
    final String PUBLIC_KEY="keyhome/local_pub.der";

       //get the private key
        File file = new File(PRIVATE_KEY);
        FileInputStream fis = new FileInputStream(file);
        DataInputStream dis = new DataInputStream(fis);

        byte[] keyBytes = new byte[(int) file.length()];
        dis.readFully(keyBytes);
        dis.close();

        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        RSAPrivateKey privKey = (RSAPrivateKey) kf.generatePrivate(spec);
       // encode("asd",(String)privKey);
        System.out.println("Exponent :" + privKey.getPrivateExponent());
        System.out.println("Modulus" + privKey.getModulus());

        //get the public key
        File file1 = new File(PUBLIC_KEY);
        FileInputStream fis1 = new FileInputStream(file1);
        DataInputStream dis1 = new DataInputStream(fis1);
        byte[] keyBytes1 = new byte[(int) file1.length()];
        dis1.readFully(keyBytes1);
        dis1.close();

        X509EncodedKeySpec spec1 = new X509EncodedKeySpec(keyBytes1);
        KeyFactory kf1 = KeyFactory.getInstance("RSA");
        RSAPublicKey pubKey = (RSAPublicKey) kf1.generatePublic(spec1);

        System.out.println("Exponent :" + pubKey.getPublicExponent());
        System.out.println("Modulus" + pubKey.getModulus());
    }
}