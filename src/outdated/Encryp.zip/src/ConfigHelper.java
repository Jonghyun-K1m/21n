
public class ConfigHelper {
	public static boolean getUsePreventXXEAttack() {
	
		return true;
	}
}
