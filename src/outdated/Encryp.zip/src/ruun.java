import java.net.InetAddress;
import java.net.UnknownHostException;

@SuppressWarnings("static-access")
public class ruun {
	
	

	private static String getServerIp() {
		
		InetAddress local = null;
		try {
			local = InetAddress.getLocalHost();
		}
		catch ( UnknownHostException e ) {
			e.printStackTrace();
		}
			
		if( local == null ) {
			return "";
		}
		else {
			String ip = local.getHostAddress();
			return ip;
		}
			
	}
	public String getClientIP(HttpServletRequest request) {

		String ip = request.getHeader("X-FORWARDED-FOR");

		if (ip == null || ip.length() == 0) {
		ip = request.getHeader("Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0) {
		ip = request.getHeader("WL-Proxy-Client-IP"); // ������
		}

		if (ip == null || ip.length() == 0) {
		ip = request.getRemoteAddr() ;
		}

		return ip;
	}
	        public static void main(String args[]) {
	        	String a = getServerIp();
	        	System.out.print(a);
	        }

}